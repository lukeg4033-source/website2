export const stats = [
  {
    id: 'components',
    value: 11107384,
    label: 'Total Components Manufactured (2024)',
  },
  {
    id: 'exports',
    value: '75%',
    label: 'Export Percentage',
  },
  {
    id: 'countries',
    value: 35,
    label: 'Countries Exported To',
  },
  {
    id: 'staff',
    value: 120,
    label: 'Hardworking Staff',
  },
];